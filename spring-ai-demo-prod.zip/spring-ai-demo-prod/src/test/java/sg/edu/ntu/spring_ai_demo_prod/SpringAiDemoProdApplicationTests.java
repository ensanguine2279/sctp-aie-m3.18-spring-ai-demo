package sg.edu.ntu.spring_ai_demo_prod;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAiDemoProdApplicationTests {

	@Test
	void contextLoads() {
	}

}
