package sg.edu.ntu.spring_ai_demo_prod;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
public class AiController {
    private final ChatClient chatClient;

    public AiController(ChatClient.Builder chatClientBuilder) {
        this.chatClient = chatClientBuilder.build();
    }

    @GetMapping("/chat")
    public String chat(@RequestParam String message) {
        return chatClient.prompt()
                .user(message)
                .call()
                .content();
    }

    @GetMapping("/support")
    public String support(@RequestParam String message) {
        return chatClient.prompt()
                .system("You are a friendly and professional customer support assistant for a CRM software company." +
                        "You help users with questions about managing customers, contacts, and sales pipelines." +
                        "Keep your answers concise and practical. " +
                        "If a question is not related to CRM or customer management, politely redirect the user.")
                .user(message)
                .call()
                .content();
    }

    @GetMapping("/analyse-ticket")
    public String analyseTicket(@RequestParam String ticket) {
        TicketAnalysis analysis= chatClient.prompt()
                .user(u -> u.text("Analyse this customer support ticket: {ticket}. " +
                        "Category must be one of: BILLING, DELIVERY, TECHNICAL, OTHER. " +
                        "Urgency must be one of: LOW, MEDIUM, HIGH")
                        .param("ticket", ticket))
                .call()
                .entity(TicketAnalysis.class);

                if(analysis.refundRequested())
                {
                    return "Routed to Finance team- "+ analysis.summary();
                }
                if(analysis.urgency().equalsIgnoreCase("HIGH"))
                {
                    return "Escalalted to Senior Support - "+ analysis.summary();
                }
                return ("Added to standard " + analysis.category() + " queue -" + analysis.summary());
    }
    

    


}

    