package sg.edu.ntu.spring_ai_demo_prod;

import java.util.random.RandomGenerator;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.vectorstore.QuestionAnswerAdvisor;
import org.springframework.ai.vectorstore.VectorStore;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@RestController
public class RagController {

    private final ChatClient chatClient;
    private final ChatClient productChatClient;

    public RagController(ChatClient.Builder chatClientBuilder, VectorStore vectorStore) {
        this.chatClient = chatClientBuilder
                .defaultSystem("You are a helpful customer support assistant for ACME CRM. " +
                        "Answer questions based only on the provided context. " +
                        "If the answer is not in the context, say you don't have that information " +
                        "and suggest contacting support@acmecrm.com.")
                .defaultAdvisors(QuestionAnswerAdvisor.builder(vectorStore).build())
                .build();

        this.productChatClient = chatClientBuilder
                .defaultSystem("You are a friendly product advisor for ACME Tech. " +
                        "Answer questions about our products using only the provided context. " +
                        "If a product or detail isn't in the context, say you don't have that " +
                        "information rather than guessing.")
                .defaultAdvisors(QuestionAnswerAdvisor.builder(vectorStore).build())
                .build();

    }

    @GetMapping("/faq")
    public String faq(@RequestParam String question) {

        return chatClient.prompt()
                .user(question)
                .call()
                .content();
    }

    @GetMapping("/product-info")
    public String productInfo(@RequestParam String question) {
        return productChatClient.prompt().
        user(question)
        .call()
        .content();
    }
    

}
