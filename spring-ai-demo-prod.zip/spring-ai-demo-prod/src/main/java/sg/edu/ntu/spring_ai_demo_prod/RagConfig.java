package sg.edu.ntu.spring_ai_demo_prod;

import java.util.ArrayList;
import java.util.List;

import org.springframework.ai.document.Document;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.reader.TextReader;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.ai.vectorstore.SimpleVectorStore;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RagConfig {

    @Bean 
    public VectorStore vectorStore(EmbeddingModel embeddingModel) {
        // Create an in-memory vector store
        SimpleVectorStore store = SimpleVectorStore.builder(embeddingModel).build();

        // Read the FAQ file directly using the classpath string
        TextReader textReader = new TextReader("classpath:faq.txt");
        List<Document> documents = textReader.get();
        // split into smaller chunks for better retrieval
        List<Document> chunks = TokenTextSplitter.builder().build().apply(documents);

      // Read and chunk the product file
       TextReader productReader = new TextReader("classpath:products.txt");
        List<Document> productDocuments = productReader.get();
        // split into smaller chunks for better retrieval
        List<Document> productChunks = TokenTextSplitter.builder().build().apply(productDocuments);


        //Combine both set of chunks, then load in one call
        List<Document> allChunks = new ArrayList<>();
        allChunks.addAll(chunks);
        allChunks.addAll(productChunks);
      

        //Load chunks into vector store
        //embeddings are genenrated, each chunk converted into vector
        store.add(allChunks);
        System.out.println(("FAQ data loaded into vector store - "+ chunks.size() +" chunks"));
        return store;

    }

}
