package sg.edu.ntu.spring_ai_demo_prod;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAiDemoProdApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringAiDemoProdApplication.class, args);
	}

}
